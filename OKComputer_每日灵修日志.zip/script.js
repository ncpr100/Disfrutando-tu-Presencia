// Sistema de Diario Digital - El Diario de la Voz del Padre
class JournalSystem {
    constructor() {
        this.currentSection = 'daily';
        this.entries = this.loadEntries();
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setTodayDate();
        this.animateElements();
        this.loadTodayEntry();
    }

    setupEventListeners() {
        // Auto-guardado en tiempo real
        document.querySelectorAll('input, textarea').forEach(element => {
            element.addEventListener('input', () => {
                this.autoSave();
            });
        });

        // Guardar al salir de un campo
        document.querySelectorAll('input, textarea').forEach(element => {
            element.addEventListener('blur', () => {
                this.autoSave();
            });
        });
    }

    setTodayDate() {
        const today = new Date().toISOString().split('T')[0];
        const dateInput = document.getElementById('today-date');
        if (dateInput && !dateInput.value) {
            dateInput.value = today;
        }
    }

    animateElements() {
        // Animar elementos al hacer scroll
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, { threshold: 0.1 });

        document.querySelectorAll('.section-card').forEach(card => {
            observer.observe(card);
        });

        // Animar título principal
        anime({
            targets: '.gradient-text',
            scale: [0.8, 1],
            opacity: [0, 1],
            duration: 1000,
            easing: 'easeOutElastic(1, .8)',
            delay: 500
        });

        // Animar tarjetas secundarias
        anime({
            targets: '.section-card',
            translateY: [50, 0],
            opacity: [0, 1],
            duration: 800,
            delay: anime.stagger(200),
            easing: 'easeOutQuart'
        });
    }

    loadEntries() {
        const stored = localStorage.getItem('journal-entries');
        return stored ? JSON.parse(stored) : {};
    }

    saveEntries() {
        localStorage.setItem('journal-entries', JSON.stringify(this.entries));
    }

    autoSave() {
        const date = document.getElementById('today-date').value;
        if (!date) return;

        const entry = {
            date: date,
            startTime: document.getElementById('start-time').value,
            endTime: document.getElementById('end-time').value,
            quietPrayer: document.getElementById('quiet-prayer').value,
            businessPressures: document.getElementById('business-pressures').value,
            familyConcerns: document.getElementById('family-concerns').value,
            otherNoise: document.getElementById('other-noise').value,
            todayPassage: document.getElementById('today-passage').value,
            highlightWord: document.getElementById('highlight-word').value,
            highlightPhrase: document.getElementById('highlight-phrase').value,
            highlightPrinciple: document.getElementById('highlight-principle').value,
            aboutGod: document.getElementById('about-god').value,
            aboutJesus: document.getElementById('about-jesus').value,
            aboutWays: document.getElementById('about-ways').value,
            aboutIdentity: document.getElementById('about-identity').value,
            whatGodSaying: document.getElementById('what-god-saying').value,
            contactPerson: document.getElementById('contact-person').value,
            actionToTake: document.getElementById('action-to-take').value,
            attitudeAdjust: document.getElementById('attitude-adjust').value,
            decisionMake: document.getElementById('decision-make').value,
            goalHydrologik: document.getElementById('goal-hydrologik').value,
            goalFamily: document.getElementById('goal-family').value,
            goalMinistry: document.getElementById('goal-ministry').value,
            goalHealth: document.getElementById('goal-health').value,
            confessionNeeded: document.getElementById('confession-needed').value,
            forgivenessNeeded: document.getElementById('forgiveness-needed').value,
            fearRelease: document.getElementById('fear-release').value,
            todayObedience: document.getElementById('today-obedience').value,
            whenObedience: document.getElementById('when-obedience').value,
            accountability: document.getElementById('accountability').value,
            faithDeclaration: document.getElementById('faith-declaration').value,
            todayScripture: document.getElementById('today-scripture').value,
            howDidIDo: document.getElementById('how-did-i-do').value,
            obedienceFruit: document.getElementById('obedience-fruit').value,
            learnedVoice: document.getElementById('learned-voice').value,
            tomorrowPlan: document.getElementById('tomorrow-plan').value
        };

        this.entries[date] = entry;
        this.saveEntries();
    }

    loadTodayEntry() {
        const today = new Date().toISOString().split('T')[0];
        const entry = this.entries[today];
        
        if (entry) {
            this.populateForm(entry);
        }
    }

    populateForm(entry) {
        Object.keys(entry).forEach(key => {
            const element = document.getElementById(this.getElementId(key));
            if (element) {
                element.value = entry[key];
            }
        });
    }

    getElementId(key) {
        const mapping = {
            date: 'today-date',
            startTime: 'start-time',
            endTime: 'end-time',
            quietPrayer: 'quiet-prayer',
            businessPressures: 'business-pressures',
            familyConcerns: 'family-concerns',
            otherNoise: 'other-noise',
            todayPassage: 'today-passage',
            highlightWord: 'highlight-word',
            highlightPhrase: 'highlight-phrase',
            highlightPrinciple: 'highlight-principle',
            aboutGod: 'about-god',
            aboutJesus: 'about-jesus',
            aboutWays: 'about-ways',
            aboutIdentity: 'about-identity',
            whatGodSaying: 'what-god-saying',
            contactPerson: 'contact-person',
            actionToTake: 'action-to-take',
            attitudeAdjust: 'attitude-adjust',
            decisionMake: 'decision-make',
            goalHydrologik: 'goal-hydrologik',
            goalFamily: 'goal-family',
            goalMinistry: 'goal-ministry',
            goalHealth: 'goal-health',
            confessionNeeded: 'confession-needed',
            forgivenessNeeded: 'forgiveness-needed',
            fearRelease: 'fear-release',
            todayObedience: 'today-obedience',
            whenObedience: 'when-obedience',
            accountability: 'accountability',
            faithDeclaration: 'faith-declaration',
            todayScripture: 'today-scripture',
            howDidIDo: 'how-did-i-do',
            obedienceFruit: 'obedience-fruit',
            learnedVoice: 'learned-voice',
            tomorrowPlan: 'tomorrow-plan'
        };
        return mapping[key] || key;
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 p-4 rounded-lg text-white z-50 ${
            type === 'success' ? 'bg-green-500' : 'bg-red-500'
        }`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        anime({
            targets: notification,
            translateX: [300, 0],
            opacity: [0, 1],
            duration: 500,
            easing: 'easeOutQuart'
        });

        setTimeout(() => {
            anime({
                targets: notification,
                translateX: [0, 300],
                opacity: [1, 0],
                duration: 500,
                easing: 'easeInQuart',
                complete: () => {
                    document.body.removeChild(notification);
                }
            });
        }, 3000);
    }
}

// Instancia global del sistema
const journal = new JournalSystem();

// Funciones globales
function showSection(sectionName) {
    // Ocultar todas las secciones
    document.querySelectorAll('.section-content').forEach(section => {
        section.classList.add('hidden');
    });
    
    // Mostrar sección seleccionada
    const targetSection = document.getElementById(`${sectionName}-section`);
    if (targetSection) {
        targetSection.classList.remove('hidden');
        
        // Animar aparición
        anime({
            targets: targetSection,
            opacity: [0, 1],
            translateY: [20, 0],
            duration: 500,
            easing: 'easeOutQuart'
        });
    }
    
    // Actualizar pestañas activas
    document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Actualizar sección actual
    journal.currentSection = sectionName;
}

function saveDailyEntry() {
    journal.autoSave();
    journal.showNotification('✅ Entrada diaria guardada con éxito');
    
    // Animar botón
    const button = event.target;
    anime({
        targets: button,
        scale: [1, 0.95, 1],
        duration: 200,
        easing: 'easeInOutQuad'
    });
}

function saveWeeklyReview() {
    const date = document.getElementById('today-date').value || new Date().toISOString().split('T')[0];
    const weeklyData = {
        themes: document.getElementById('weekly-themes').value,
        instructions: document.getElementById('weekly-instructions').value,
        obeyedWell: document.getElementById('obeyed-well').value,
        doubtsFailures: document.getElementById('doubts-failures').value,
        obedienceFruit: document.getElementById('obedience-fruit-week').value,
        doorsOpened: document.getElementById('doors-opened').value,
        timeAdjustments: document.getElementById('time-adjustments').value,
        faithAreas: document.getElementById('faith-areas').value
    };
    
    // Guardar en localStorage
    const weeklyEntries = JSON.parse(localStorage.getItem('weekly-entries') || '{}');
    weeklyEntries[date] = weeklyData;
    localStorage.setItem('weekly-entries', JSON.stringify(weeklyEntries));
    
    journal.showNotification('✅ Revisión semanal guardada con éxito');
}

function saveMonthlyReflection() {
    const date = document.getElementById('today-date').value || new Date().toISOString().split('T')[0];
    const monthlyData = {
        fatherCharacter: document.getElementById('father-character').value,
        significantDirections: document.getElementById('significant-directions').value,
        voiceGrowth: document.getElementById('voice-growth').value,
        keyObediences: document.getElementById('key-obediences').value
    };
    
    // Guardar en localStorage
    const monthlyEntries = JSON.parse(localStorage.getItem('monthly-entries') || '{}');
    monthlyEntries[date] = monthlyData;
    localStorage.setItem('monthly-entries', JSON.stringify(monthlyEntries));
    
    journal.showNotification('✅ Reflexión mensual guardada con éxito');
}

function savePromises() {
    const date = document.getElementById('today-date').value || new Date().toISOString().split('T')[0];
    const promisesData = {
        isaiah30_21: document.getElementById('isaiah-30-21').value,
        psalm32_8: document.getElementById('psalm-32-8').value,
        psalm25_14: document.getElementById('psalm-25-14').value
    };
    
    // Guardar en localStorage
    const promisesEntries = JSON.parse(localStorage.getItem('promises-entries') || '{}');
    promisesEntries[date] = promisesData;
    localStorage.setItem('promises-entries', JSON.stringify(promisesEntries));
    
    journal.showNotification('✅ Reflexiones sobre promesas guardadas con éxito');
}

function loadArchiveEntry() {
    const selectedDate = document.getElementById('archive-date').value;
    if (!selectedDate) {
        journal.showNotification('⚠️ Por favor selecciona una fecha', 'error');
        return;
    }
    
    const entry = journal.entries[selectedDate];
    const archiveContent = document.getElementById('archive-content');
    
    if (entry) {
        archiveContent.innerHTML = formatArchiveEntry(entry, selectedDate);
    } else {
        archiveContent.innerHTML = `
            <div class="text-center text-gray-500 py-8">
                <p>No hay entrada para ${new Date(selectedDate).toLocaleDateString('es-ES')}</p>
                <p class="text-sm mt-2">¿Te gustaría crear una entrada para esta fecha?</p>
            </div>
        `;
    }
}

function formatArchiveEntry(entry, date) {
    const formattedDate = new Date(date).toLocaleDateString('es-ES', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    
    return `
        <div class="bg-white rounded-lg p-6 shadow-lg">
            <h3 class="text-xl font-bold gradient-text mb-4">${formattedDate}</h3>
            
            <div class="space-y-4">
                ${entry.todayPassage ? `
                    <div class="scripture-highlight p-3 rounded-lg">
                        <strong>Pasaje de hoy:</strong> ${entry.todayPassage}
                    </div>
                ` : ''}
                
                ${entry.whatGodSaying ? `
                    <div>
                        <strong>Lo que el Padre dijo:</strong>
                        <p class="mt-1 text-gray-700">${entry.whatGodSaying}</p>
                    </div>
                ` : ''}
                
                ${entry.todayObedience ? `
                    <div>
                        <strong>Obediencia de hoy:</strong>
                        <p class="mt-1 text-gray-700">${entry.todayObedience}</p>
                    </div>
                ` : ''}
                
                ${entry.faithDeclaration ? `
                    <div class="bg-gradient-to-r from-purple-50 to-blue-50 p-3 rounded-lg">
                        <strong>Declaración de fe:</strong>
                        <p class="mt-1 text-gray-700">${entry.faithDeclaration}</p>
                    </div>
                ` : ''}
                
                ${entry.learnedVoice ? `
                    <div>
                        <strong>Aprendí sobre Su voz:</strong>
                        <p class="mt-1 text-gray-700">${entry.learnedVoice}</p>
                    </div>
                ` : ''}
            </div>
            
            <div class="mt-6 text-center">
                <button onclick="loadEntryToEdit('${date}')" class="save-btn text-white px-4 py-2 rounded-lg font-semibold mr-2">
                    ✏️ Editar esta entrada
                </button>
                <button onclick="deleteEntry('${date}')" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-semibold">
                    🗑️ Eliminar
                </button>
            </div>
        </div>
    `;
}

function loadEntryToEdit(date) {
    // Cargar la entrada en el formulario principal
    const entry = journal.entries[date];
    if (entry) {
        journal.populateForm(entry);
        
        // Cambiar a la sección de entrada diaria
        showSection('daily');
        
        // Actualizar la fecha
        document.getElementById('today-date').value = date;
        
        journal.showNotification('✅ Entrada cargada para edición');
    }
}

function deleteEntry(date) {
    if (confirm('¿Estás seguro de que quieres eliminar esta entrada?')) {
        delete journal.entries[date];
        journal.saveEntries();
        
        // Recargar el archivo
        loadArchiveEntry();
        
        journal.showNotification('✅ Entrada eliminada con éxito');
    }
}

function exportAllEntries() {
    const data = {
        daily: journal.entries,
        weekly: JSON.parse(localStorage.getItem('weekly-entries') || '{}'),
        monthly: JSON.parse(localStorage.getItem('monthly-entries') || '{}'),
        promises: JSON.parse(localStorage.getItem('promises-entries') || '{}')
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(dataBlob);
    link.download = `diario-voz-padre-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    
    journal.showNotification('✅ Diario exportado con éxito');
}

// Función para importar datos (útil para restaurar)
function importEntries(file) {
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);
            
            if (data.daily) {
                localStorage.setItem('journal-entries', JSON.stringify(data.daily));
            }
            if (data.weekly) {
                localStorage.setItem('weekly-entries', JSON.stringify(data.weekly));
            }
            if (data.monthly) {
                localStorage.setItem('monthly-entries', JSON.stringify(data.monthly));
            }
            if (data.promises) {
                localStorage.setItem('promises-entries', JSON.stringify(data.promises));
            }
            
            journal.entries = data.daily || {};
            journal.showNotification('✅ Diario importado con éxito');
            
            // Recargar la página para reflejar los cambios
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } catch (error) {
            journal.showNotification('❌ Error al importar el archivo', 'error');
        }
    };
    reader.readAsText(file);
}

// Atajos de teclado
document.addEventListener('keydown', function(e) {
    // Ctrl+S para guardar
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        saveDailyEntry();
    }
    
    // Ctrl+E para exportar
    if (e.ctrlKey && e.key === 'e') {
        e.preventDefault();
        exportAllEntries();
    }
    
    // Ctrl+1, Ctrl+2, etc. para cambiar de sección
    if (e.ctrlKey && ['1', '2', '3', '4', '5'].includes(e.key)) {
        e.preventDefault();
        const sections = ['daily', 'weekly', 'monthly', 'promises', 'archive'];
        showSection(sections[parseInt(e.key) - 1]);
    }
});

// Efectos visuales adicionales
function addFloatingElements() {
    const floatingElements = document.querySelectorAll('.floating-element');
    floatingElements.forEach(element => {
        anime({
            targets: element,
            translateY: [-10, 10],
            duration: 3000 + Math.random() * 2000,
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutSine'
        });
    });
}

// Inicializar efectos adicionales cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    addFloatingElements();
    
    // Efecto de escritura para el subtítulo
    if (document.querySelector('.typed-text')) {
        new Typed('.typed-text', {
            strings: ['Una guía diaria para escuchar y obedecer'],
            typeSpeed: 50,
            showCursor: false
        });
    }
});

// Función para obtener estadísticas
function getJournalStats() {
    const entries = Object.keys(journal.entries);
    const totalDays = entries.length;
    const thisMonth = entries.filter(date => {
        const entryDate = new Date(date);
        const now = new Date();
        return entryDate.getMonth() === now.getMonth() && entryDate.getFullYear() === now.getFullYear();
    }).length;
    
    const thisWeek = entries.filter(date => {
        const entryDate = new Date(date);
        const now = new Date();
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        return entryDate >= weekAgo && entryDate <= now;
    }).length;
    
    return { totalDays, thisMonth, thisWeek };
}

// Mostrar estadísticas en el footer (opcional)
function displayStats() {
    const stats = getJournalStats();
    const statsElement = document.createElement('div');
    statsElement.className = 'mt-4 text-sm text-gray-600';
    statsElement.innerHTML = `
        <p>📊 Estadísticas: ${stats.totalDays} días registrados | ${stats.thisMonth} este mes | ${stats.thisWeek} esta semana</p>
    `;
    
    const footer = document.querySelector('footer .max-w-7xl');
    if (footer) {
        footer.appendChild(statsElement);
    }
}

// Llamar a displayStats después de un momento
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(displayStats, 2000);
});